//
//  PaymentRequestViewController.swift
//  mcandle-ios-app
//
//  Created by 이상헌 on 2025/08/09.
//

import UIKit

class PaymentRequestViewController: UIViewController {

    @IBAction func touchedOK(_ sender: Any) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        guard let paymentInfoVC = sb.instantiateViewController(
            withIdentifier: "PaymentInformationViewController") as? PaymentInformationViewController else { return }
        navigationController?.pushViewController(paymentInfoVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
