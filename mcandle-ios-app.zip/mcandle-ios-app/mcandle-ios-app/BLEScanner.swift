//
//  BLEScanner.swift
//  mcandle-ios-scanner
//
//  Created by 이상헌 on 2025/07/31.
//

import Foundation
import CoreBluetooth
import OSLog
import UIKit

/// BLE 스캐너: CBCentralManagerDelegate 프로토콜 구현
final class BLEScanner: NSObject, ObservableObject {
    
    static let shared = BLEScanner()
    private var central: CBCentralManager!
    
    override init() {
        super.init()
        //central = CBCentralManager(delegate: self, queue: nil)
    }
    
    var onDetectPOS: ((String) -> Void)?
}

// MARK: - CBCentralManagerDelegate
extension BLEScanner: CBCentralManagerDelegate {
    
    /// Bluetooth 상태 변경 시 호출
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            self.central.scanForPeripherals(withServices: nil,
                                       options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
            print("🔍 스캔 시작")
        case .unauthorized:
            print("❗️Bluetooth 권한이 없습니다")
        case .poweredOff:
            print("❗️Bluetooth가 꺼져 있습니다")
        default:
            break
        }
    }
    
    /// 주변에서 Peripheral 발견 시 호출
    func centralManager(_ central: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any],
                        rssi RSSI: NSNumber) {
        let targetLocalName: String? = "RFstar"
        
        let name = peripheral.name ?? "이름 없음"
        if targetLocalName != String(name.prefix(6)) {
            return
        }
        
        if let advertised = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID] {
            // not a iBeacon
            print(advertised)
            return
        }
        
//        if let mfgData = advertisementData[CBAdvertisementDataManufacturerDataKey] as? Data {
////            if let frame = try? parseIBeacon(manufacturerData: mfgData, rssi: RSSI.intValue) {
////                print(frame)
////            }
////            else {
////                return
////            }
//
//            print("exists ", mfgData)
//            return
//        }
//        else {
//            print("does not exists ")
//            return
//        }

//        let localName = advertisementData[CBAdvertisementDataLocalNameKey] as? String
//        guard let scannedName = localName else {
//            return
//        }
//        
//        if targetLocalName != String(scannedName.prefix(6)) {
//            return
//        }
        
//        let advertised = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID]
//        guard let unwrappedCBUUIDs = advertised else {
//            return
//        }
//        
//        let uuid = unwrappedCBUUIDs[0].uuidString
//        print(uuid)
        
//        let slice = uuid[uuid.index(uuid.startIndex, offsetBy: 14)..<uuid.index(uuid.startIndex, offsetBy: 18)]
//        let phoneString = String(slice)
//        let phone = UserDefaults.standard.string(forKey: "phoneNumber") ?? "1234"
        
//        if phoneString != phone {
//            return
//        }
        
        print("📡 발견: \(name)  RSSI: \(RSSI)")
        
        stopScanning()
        
        self.onDetectPOS?("")
    }
    
    func startScanning() {
        if central == nil {
            central = CBCentralManager(delegate: self, queue: nil)
            return
        }
        
        if !self.central.isScanning {
            self.central.scanForPeripherals(withServices: nil,
                                       options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
            print("🔍 스캔 시작")
        }
    }
    
    /// 필요 시 스캔 중단 메서드
    func stopScanning() {
        if self.central.isScanning {
            self.central.stopScan()
            print("🛑 스캔 중단")
        }
    }
}
