//
//  IBeaconFrame.swift
//  mcandle-ios-app
//
//  Created by 이상헌 on 2025/10/20.
//
import Foundation

struct IBeaconFrame: CustomStringConvertible {
    let uuid: UUID
    let major: UInt16
    let minor: UInt16
    let txPower: Int8   // measured power at 1m
    let rssi: Int       // from scan result

    var description: String {
        "iBeacon(uuid: \(uuid), major: \(major), minor: \(minor), txPower: \(txPower), rssi: \(rssi))"
    }
}

enum IBeaconParseError: Error {
    case notAppleManufacturer
    case notIBeaconType
    case invalidLength
}

func parseIBeacon(manufacturerData data: Data, rssi: Int) throws -> IBeaconFrame {
    // Expected length: 25 bytes = 2(company) + 1(type) + 1(len) + 16(UUID) + 2(major) + 2(minor) + 1(tx)
    guard data.count >= 25 else { throw IBeaconParseError.invalidLength }

    // Offsets
    let companyID = (UInt16(data[0]) << 8) | UInt16(data[1])  // big-endian
    guard companyID == 0x004C else { throw IBeaconParseError.notAppleManufacturer } // Apple

    let type = data[2]
    let length = data[3]
    guard type == 0x02, length == 0x15 else { throw IBeaconParseError.notIBeaconType }

    // UUID (bytes 4...19)
    let uuidBytes = data.subdata(in: 4..<20)
    let uuid = UUID(uuid: (
        uuidBytes[0],  uuidBytes[1],  uuidBytes[2],  uuidBytes[3],
        uuidBytes[4],  uuidBytes[5],  uuidBytes[6],  uuidBytes[7],
        uuidBytes[8],  uuidBytes[9],  uuidBytes[10], uuidBytes[11],
        uuidBytes[12], uuidBytes[13], uuidBytes[14], uuidBytes[15]
    ))

    // major/minor are big-endian
    let major = (UInt16(data[20]) << 8) | UInt16(data[21])
    let minor = (UInt16(data[22]) << 8) | UInt16(data[23])

    // Tx power (signed int8)
    let txPower = Int8(bitPattern: data[24])

    return IBeaconFrame(uuid: uuid, major: major, minor: minor, txPower: txPower, rssi: rssi)
}

extension UUID {
    /// 16바이트 배열을 UUID로 변환하는 편의 생성자 (Swift 6 대응)
    init(bytes: [UInt8]) {
        precondition(bytes.count == 16, "UUID must be exactly 16 bytes")

        let uuid = uuid_t(
            bytes[0],  bytes[1],  bytes[2],  bytes[3],
            bytes[4],  bytes[5],  bytes[6],  bytes[7],
            bytes[8],  bytes[9],  bytes[10], bytes[11],
            bytes[12], bytes[13], bytes[14], bytes[15]
        )
        self.init(uuid: uuid)
    }
}
