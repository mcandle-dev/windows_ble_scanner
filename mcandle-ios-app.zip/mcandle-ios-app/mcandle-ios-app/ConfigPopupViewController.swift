//
//  ConfigPopupViewController.swift
//  mcandle-ios-app
//
//  Created by 이상헌 on 2025/08/01.
//

import UIKit

class ConfigPopupViewController: UIViewController {
    @IBOutlet weak var membershipID: UITextField!
    @IBOutlet weak var phoneNumber: UITextField!
    
    @IBAction func resetDemo(_ sender: Any) {
        let id = membershipID.text ?? "1234567890ABCDEF"
        let phone = phoneNumber.text ?? "1234"
        
        if id.count != 16 {
            let alert = UIAlertController(title: "경고", message: "멤버쉽 번호는 16자리입니다.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "확인", style: .default))
            present(alert, animated: true)
            return
        }
        
        if phone.count != 4 {
            let alert = UIAlertController(title: "경고", message: "전화번호는 4자리입니다.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "확인", style: .default))
            present(alert, animated: true)
            return
        }
        
        UserDefaults.standard.set(id, forKey: "membershipID")
        UserDefaults.standard.set(phone, forKey: "phoneNumber")
        
        //BLEScanner.shared.stopScanning()
        //BLEAdvertiser.shared.stop()
        
        let firstSlice = id[id.startIndex..<id.index(id.startIndex, offsetBy: 8)]
        let secondSlice = id[id.index(id.startIndex, offsetBy: 8)..<id.index(id.startIndex, offsetBy: 12)]
        let thirdSlice = id[id.index(id.startIndex, offsetBy: 12)..<id.index(id.startIndex, offsetBy: 16)]
        let firstString = String(firstSlice)
        let secondString = String(secondSlice)
        let thirdString = String(thirdSlice)
        
        let newUUID = firstString + "-" + secondString + "-" + thirdString + "-" + phone + "-1234567890AB"
        print(newUUID)
        BLEPeripheral.shared.setUUID(uuid: newUUID)
        
        //BLEAdvertiser.shared.start()
        //BLEScanner.shared.startScanning()
        
        navigationController?.popToRootViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        membershipID.text = UserDefaults.standard.string(forKey: "membershipID") ?? "1234567890ABCDEF"
        membershipID.autocorrectionType = .no
        membershipID.spellCheckingType = .no
        
        phoneNumber.text = UserDefaults.standard.string(forKey: "phoneNumber") ?? "1234"
        phoneNumber.autocorrectionType = .no
        phoneNumber.spellCheckingType = .no
    }
}
