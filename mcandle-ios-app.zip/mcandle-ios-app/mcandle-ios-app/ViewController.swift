//
//  ViewController.swift
//  mcandle-ios-app
//
//  Created by 이상헌 on 2025/07/31.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func touchedMenuButton(_ sender: Any) {
        //performSegue(withIdentifier: "goConfig", sender: self)
        let sb = UIStoryboard(name: "Main", bundle: nil)
        guard let configVC = sb.instantiateViewController(
            withIdentifier: "ConfigPopupViewController") as? ConfigPopupViewController else { return }
        navigationController?.pushViewController(configVC, animated: true)
    }
    
    @IBAction func touchedCheckOutButton(_ sender: UIButton) {
        UIView.animate(withDuration: 0.1,
                           animations: {
                sender.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
            }) { _ in
                UIView.animate(withDuration: 0.1) {
                    sender.transform = .identity
                }
            }
        
        showCenterBLECommunication()
        
        BLEPeripheral.shared.start()
        //BLEScanner.shared.startScanning()
    }
    
    @IBAction func unwindToMain(_ segue: UIStoryboardSegue) { }
    
    @IBOutlet weak var wifiButton: UIButton!
    
    func showCenterBLECommunication() {
        wifiButton.isHidden = false
        startPulsing(wifiButton)
        DispatchQueue.main.asyncAfter(deadline: .now() + 60) {
            self.stopPulsing(self.wifiButton)
            self.wifiButton.isHidden = true
            BLEPeripheral.shared.stop()
            //BLEScanner.shared.stopScanning()
        }
    }
    
    func startPulsing(_ view: UIView) {
        let pulse = CABasicAnimation(keyPath: "transform.scale")
        pulse.fromValue = 1.0
        pulse.toValue = 1.5
        pulse.duration = 0.5
        pulse.autoreverses = true
        pulse.repeatCount = Float.infinity
        view.layer.add(pulse, forKey: "pulse")
    }

    func stopPulsing(_ view: UIView) {
        view.layer.removeAnimation(forKey: "pulse")
    }
    
    func goPaymentRequest() {
        stopPulsing(wifiButton)
        wifiButton.isHidden = true
        
        BLEPeripheral.shared.stop()
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        guard let paymentRequestVC = sb.instantiateViewController(
            withIdentifier: "PaymentRequestViewController") as? PaymentRequestViewController else { return }
        navigationController?.pushViewController(paymentRequestVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        definesPresentationContext = true
        navigationItem.backButtonTitle = "홈"
        
        BLEPeripheral.shared.bluetoothOn()
        
        BLEScanner.shared.onDetectPOS = {
            [weak self] name in
            self?.goPaymentRequest()
        }
    }
}

