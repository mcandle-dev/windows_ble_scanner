//
//  PaymentViewController.swift
//  mcandle-ios-app
//
//  Created by 이상헌 on 2025/08/02.
//

import UIKit

class PaymentViewController: UIViewController {

    @IBOutlet var radioButtons: [UIButton]!
    
    var selectedButtonIndex: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        var config = UIButton.Configuration.plain()
        config.baseBackgroundColor = .clear
        
        // Do any additional setup after loading the view.
        for (_, button) in radioButtons.enumerated() {
            button.isSelected = false
            button.setImage(UIImage(systemName: "circle"), for: .normal) // 기본 이미지 설정
            button.setImage(UIImage(systemName: "largecircle.fill.circle"), for: .selected) // 선택 이미지 설정
            //button.configuration = config
        }
        selectButton(at: 0) // 첫 번째 버튼 선택
    }
    
    @IBAction func radioButtonsTapped(_ sender: UIButton) {
        guard let index = radioButtons.firstIndex(of: sender) else { return }
        selectButton(at: index)
    }
    
    func selectButton(at index: Int) {
        // 기존 선택 해제
        if let previousIndex = selectedButtonIndex {
            radioButtons[previousIndex].isSelected = false
        }

        // 새 선택 설정
        radioButtons[index].isSelected = true
        selectedButtonIndex = index
    }
    
    @IBAction func touchedPayment(_ sender: Any) {
        let alert = UIAlertController(title: "완료", message: "결제되었습니다.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "확인", style: .default) { _ in
            self.handleOK()
        }
        alert.addAction(okAction)
        present(alert, animated: true)
    }
    
    private func handleOK() {
        navigationController?.popToRootViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
