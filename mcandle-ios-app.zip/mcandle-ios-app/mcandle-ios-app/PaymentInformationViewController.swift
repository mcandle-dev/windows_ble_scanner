//
//  PaymentInformationViewController.swift
//  mcandle-ios-app
//
//  Created by 이상헌 on 2025/08/01.
//

import UIKit

class PaymentInformationViewController: UIViewController {

    @IBAction func touchedPayment(_ sender: Any) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        guard let paymentVC = sb.instantiateViewController(
            withIdentifier: "PaymentViewController") as? PaymentViewController else { return }
        navigationController?.pushViewController(paymentVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
