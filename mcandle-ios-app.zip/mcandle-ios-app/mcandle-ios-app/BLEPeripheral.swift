//
//  BLEAdvertiser.swift
//  mcandle-ios-app
//
//  Created by 이상헌 on 2025/07/31.
//

import Foundation
import CoreBluetooth
import OSLog           // iOS 14+ 로그 출력용 (선택)

/// 단순 BLE Advertiser.
/// 앱이 포그라운드에 있을 때만 광고하며, 백그라운드 광고가 필요하면
/// 프로젝트 ‘Signing & Capabilities > Background Modes’에서
/// **Uses Bluetooth LE accessories** 와 **Acts as a Bluetooth LE accessory**를 활성화하세요.
final class BLEPeripheral: NSObject,ObservableObject {
    
    // MARK: - Public Interface
    static let shared = BLEPeripheral()
    
    private var peripheralManager: CBPeripheralManager!
    private var orderCharacteristic: CBMutableCharacteristic!
    private var notifyCharacteristic: CBMutableCharacteristic!
    
    /// 광고용 서비스 UUID (임의 생성 예시)
    private var serviceUUIDForAdvertise = CBUUID(string: "12345678-90AB-CDEF-9872-1234567890AB")
    private var serviceUUIDForConnect = CBUUID(string: "0000fff0-0000-1000-8000-00805f9b34fb")
    private var orderUUID = CBUUID(string: "0000fff1-0000-1000-8000-00805f9b34fb")
    private var notifyUUID = CBUUID(string: "0000fff2-0000-1000-8000-00805f9b34fb")
    
    func setUUID(uuid: String) {
        serviceUUIDForAdvertise = CBUUID(string: uuid)
    }
    
    func getUUID() {
        let id = UserDefaults.standard.string(forKey: "membershipID") ?? "1234567890ABCDEF"
        let phone = UserDefaults.standard.string(forKey: "phoneNumber") ?? "1234"
        
        let firstSlice = id[id.startIndex..<id.index(id.startIndex, offsetBy: 8)]
        let secondSlice = id[id.index(id.startIndex, offsetBy: 8)..<id.index(id.startIndex, offsetBy: 12)]
        let thirdSlice = id[id.index(id.startIndex, offsetBy: 12)..<id.index(id.startIndex, offsetBy: 16)]
        let firstString = String(firstSlice)
        let secondString = String(secondSlice)
        let thirdString = String(thirdSlice)
        
        let newUUID = firstString + "-" + secondString + "-" + thirdString + "-" + phone + "-1234567890AB"
        setUUID(uuid: newUUID)
    }
    
    func bluetoothOn() {
        guard peripheralManager.state == .poweredOn else {
            logger.error("Bluetooth powered OFF")
            return
        }
    }
    
    /// 광고 시작
    func start() {
        guard peripheralManager.state == .poweredOn else {
            logger.error("Bluetooth powered OFF")
            return
        }
        //if peripheralManager.isAdvertising { return }
        
        getUUID()
        
        // Advertise: 로컬 이름 & 서비스 UUID
        let advertisement: [String: Any] = [
            CBAdvertisementDataLocalNameKey: "mcandle",
            CBAdvertisementDataServiceUUIDsKey: [serviceUUIDForAdvertise]
        ]
        peripheralManager.startAdvertising(advertisement)
        //logger.info("Advertising Started")
    }
    
    /// 광고 중지
    func stop() {
        peripheralManager.stopAdvertising()
        logger.info("Advertising stopped")
    }
    
    private let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "BLEAdvertiser",
                                category: "BLE")
    
    override init() {
        super.init()
        peripheralManager = CBPeripheralManager(delegate: self, queue: nil)
    }
}

// MARK: - CBPeripheralManagerDelegate
extension BLEPeripheral: CBPeripheralManagerDelegate {
    private func setupService() {
        // ★ 중앙 -> iOS 쓰기 허용: .write / .writeWithoutResponse
        // ★ iOS -> 중앙 알림 전송: .notify
        orderCharacteristic = CBMutableCharacteristic(
            type: orderUUID,
            properties: [.writeWithoutResponse, .write],
            value: nil,
            permissions: [.writeable]
        )
        
        notifyCharacteristic = CBMutableCharacteristic(
            type: notifyUUID,
            properties: [.read, .notify],
            value: nil,
            permissions: [.readable]
        )
        
        let service = CBMutableService(type: serviceUUIDForConnect, primary: true)
        service.characteristics = [orderCharacteristic, notifyCharacteristic]
        
        peripheralManager.add(service)
        
        logger.info("Bluetooth service registered")
    }
    
    /// Bluetooth 전원 상태·권한 변경 시 호출
    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        switch peripheral.state {
        case .poweredOn:
            logger.info("Bluetooth powered ON")
            setupService()
            //BLEAdvertiser.shared.start()
        case .unauthorized:
            logger.error("Bluetooth access denied")
        case .poweredOff:
            logger.warning("Bluetooth powered OFF")
        default:
            logger.debug("Bluetooth state: \(peripheral.state.rawValue)")
        }
    }
    
    /// Advertising 시작 완료 시 호출
    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager,
                                              error: Error?) {
        if let error = error {
            logger.error("Advertising start failed: \(error.localizedDescription)")
        } else {
            logger.info("Advertising started")
        }
    }
    
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        logger.info("request received - peripheralManager")
        for request in requests {
            print(request.characteristic.uuid)
            if request.characteristic.uuid == orderUUID {
                let received = request.value ?? Data()
                print("data received:", received)
                
                // 요청 승인 (value 유지)
                peripheralManager.respond(to: request, withResult: .success)
            }
        }
    }
    
//    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
//        logger.info("request received - peripheralManager")
//        for request in requests {
//            if let value = request.value,
//               let message = String(data: value, encoding: .utf8) {
//                print("수신된 메시지: \(message)")
//            }
//            peripheral.respond(to: request, withResult: .success)
//        }
//    }
}
